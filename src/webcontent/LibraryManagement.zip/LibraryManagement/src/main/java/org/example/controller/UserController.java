package org.example.controller;

import org.example.dto.AddressDTO;
import org.example.dto.OrderBookDTO;
import org.example.dto.UserDTO;
import org.example.model.Address;
import org.example.model.Book;
import org.example.model.OrderBook;
import org.example.model.User;
import org.example.service.AddressService;
import org.example.service.BooksService;
import org.example.service.OrderBooksService;
import org.example.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import java.security.Principal;
import java.util.*;

@RestController
public class UserController {
    private static final String ADDRESS = "addressDTO";
    private static final String USERID = "userId";

    @Autowired
    UserService userService;
    @Autowired
    AddressService addressService;
    @Autowired
    BooksService booksService;
    @Autowired
    OrderBooksService orderBooksService;

    @RequestMapping(value = "/register")
    public ModelAndView register(Principal principal) {
        ModelAndView mav = new ModelAndView("registerForm");
        mav.addObject("user", new User());
        return mav;
    }

    @PostMapping(value = "/saveUser")
    public ModelAndView saveUser(@ModelAttribute("user") UserDTO userDTO) {
        return userService.saveUser(userDTO);

    }

//    @RequestMapping("/userHome")
//    public ModelAndView userHome(ModelMap model, Principal principal) {
//        User users = getUsersLogin(principal);
//        ModelAndView modelAndView = new ModelAndView("userHome");
//        modelAndView.addObject("user", users);
//        return modelAndView;
//    }

    @GetMapping(value = "/home")
    public ModelAndView home(ModelMap model, Principal principal) {
        return userService.validateAndReturnHome(principal);
    }

//    private User getUsersLogin(Principal principal) {
//        String loggedInUserName = principal.getName();
//        return userService.getUserByUserName(loggedInUserName);
//    }

    @GetMapping(value = "/login")
    public ModelAndView login(ModelMap model) {
        return new ModelAndView("login");
    }

    @GetMapping(value = "/loginError")
    public ModelAndView loginError(Principal principal) {
        ModelAndView model = new ModelAndView("login");
        model.addObject("error", "true");
        return model;
    }

    @GetMapping(value = "/403")
    public ModelAndView accessDenied(Principal user) {
        return userService.errorMessage(user);
    }

    @GetMapping(value = "/myProfile/{userId}")
    public ModelAndView myProfile(@PathVariable int userId) {
        ModelAndView mav = new ModelAndView("myProfile");
        User user = userService.getUserById(userId);
        mav.addObject("user", user);
        return mav;
    }

    @PostMapping(value = "/profileUpdate")
    public ModelAndView profileUpdate(@ModelAttribute("user") UserDTO userDTO) {
        userService.updateUserProfile(userDTO);
        return new ModelAndView("profileUpdatedSuccess");
    }

    @GetMapping(value = "/addAddress/{userId}")
    public ModelAndView addAddress(@PathVariable int userId) {
        ModelAndView mav = new ModelAndView("addressForm");
        mav.addObject(ADDRESS, new Address());
        return mav;
    }

    @PostMapping(value = "/saveAddress/{userId}")
    public ModelAndView saveAddress(@ModelAttribute("address") AddressDTO address, @ModelAttribute("user") UserDTO user, @PathVariable int userId) {
        addressService.addAddress(address, userId, user);
        return new ModelAndView("addressAddedSuccessfully");
    }


    @GetMapping(value = "/displayAddress/{userId}")
    public ModelAndView displayAddress(@PathVariable int userId) {
        ModelAndView mav = new ModelAndView("displayAddress");
        List<Address> addressList = addressService.displayAddressById(userId);
        mav.addObject(ADDRESS, addressList);
        return mav;
    }

    @GetMapping(value = "/editAddress")
    public ModelAndView editAddress(@RequestParam("userId") int userId, @RequestParam("addressId") int addressId) {
        ModelAndView mav = new ModelAndView("editAddress");
        User user = userService.getUserById(userId);
        Address address = addressService.findAddressById(addressId);
        mav.addObject(ADDRESS, address);
        mav.addObject(USERID, user);
        return mav;
    }

    @PostMapping(value = "/addressUpdate")
    public ModelAndView addressUpdate(@ModelAttribute("address") AddressDTO address) {
        addressService.addressUpdate(address);
        return new ModelAndView("addressUpdatedSuccessfully");
    }

    @GetMapping(value = "/book/{userId}")
    public ModelAndView bookList(@PathVariable int userId) {
        return booksService.displayCustomBooks(userId);
    }

    @GetMapping(value = "/displayBookToOrder")
    public ModelAndView orderBook(@RequestParam("bookId") int bookId, @RequestParam("userId") int userId) {
        ModelAndView mav = new ModelAndView("displayBookToOrder");
        OrderBook orderBook = new OrderBook();
        mav.addObject("orderBook", orderBook);
        mav.addObject(USERID, userId);
        mav.addObject("bookId", bookId);
        return mav;
    }

    @PostMapping(value = "/placeOrder")
    public ModelAndView placeOrder(@ModelAttribute("orderBook") OrderBookDTO orderBookDTO, @RequestParam("bookId") int bookId, @RequestParam("userId") int userId) {
        orderBooksService.saveBookOrder(orderBookDTO, bookId, userId);
        return new ModelAndView("orderPlacedSuccess");
    }

    @GetMapping(value = "/myOrder/{userId}")
    public ModelAndView myOrder(@PathVariable int userId) {
        ModelAndView mav = new ModelAndView("myOrders");
        List<OrderBook> orderBook = orderBooksService.findApprovedOrders(userId);
        List<Book> bookList = new ArrayList<>();
        for (OrderBook orderBooks : orderBook) {
            Book book = booksService.getBookById(orderBooks.getBookId());
            bookList.add(book);
        }
        mav.addObject("bookList", bookList);
        mav.addObject("book", new Book());
        return mav;
    }

    @GetMapping(value = "/searchBook/{bookId}")
    public ModelAndView searchBook(@PathVariable int bookId) {
        try {
            ModelAndView mav = new ModelAndView();
            mav.addObject("searchedBookId", bookId);
            Book book = booksService.findById(bookId);
            if (book != null) {
                mav.setViewName("displaySearchBook");
                mav.addObject("book", book);
            } else {
                mav.setViewName("noSuchId");
                mav.addObject("error", "Book not found");
            }
            return mav;
        }
        catch (NoSuchElementException noSuchElementException){
            ModelAndView mav = new ModelAndView();
            mav.setViewName("noSuchId");
            return mav;
        }

    }
}

